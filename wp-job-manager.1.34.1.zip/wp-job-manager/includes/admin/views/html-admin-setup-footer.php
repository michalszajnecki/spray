<?php
/**
 * File containing the view used in the footer of the setup pages.
 *
 * @package wp-job-manager
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</div>
